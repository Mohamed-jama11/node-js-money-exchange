import { router, Route, Link } from "react-router-dom";

const App = () => {
  return (
    <div className="App">
      <h1>React App</h1>
    </div>
  );
};
export default App;
