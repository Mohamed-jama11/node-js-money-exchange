# Money Exchange Backend App



## Getting Started

### BackEnd 


- Node.js
- MongoDB
- Express
- ...

### Installation


1. Clone the repository:

   ```bash
   git clone https://github.com/your-username/money_exchange_backend_App.git

   
` cd money_exchange_backend_App
`


` npm i 
`

`npm start`

### Usage 

*  `npm start` then signup then login 





